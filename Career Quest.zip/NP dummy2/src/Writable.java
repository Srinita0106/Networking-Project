public interface Writable {
    void write(String message);
}